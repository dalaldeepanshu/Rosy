import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./src/pages/**/*.{ts,tsx}",
    "./src/components/**/*.{ts,tsx}",
    "./src/app/**/*.{ts,tsx}",
  ],
  theme: {
    container: {
      center: true,
      padding: "1rem",
    },
    extend: {
      colors: {
        // Rosy design tokens
        blush: {
          DEFAULT: "#FBF6F4", // app background — warm porcelain, not cream/terracotta
          soft: "#F5EBE8",
          border: "#EBDDD9",
        },
        surface: "#FFFFFF",
        ink: {
          DEFAULT: "#3A2530", // deep plum-wine, primary text
          muted: "#8C7480", // dusty mauve, secondary text
          faint: "#B7A6AD",
        },
        rose: {
          50: "#FCEEF2",
          100: "#F6D6E0",
          300: "#E58FA8",
          500: "#C9587A", // primary brand accent
          600: "#AD4368",
          700: "#8A3454",
        },
        sage: {
          DEFAULT: "#6E9C82", // presence / online dot
          light: "#DCEAE1",
        },
        gold: {
          DEFAULT: "#D9A054", // unread badge / highlight
          light: "#F5E4C8",
        },
        border: "#EBDDD9",
        ring: "#C9587A",
        background: "#FBF6F4",
        foreground: "#3A2530",
        primary: {
          DEFAULT: "#C9587A",
          foreground: "#FFFFFF",
        },
        secondary: {
          DEFAULT: "#F5EBE8",
          foreground: "#3A2530",
        },
        muted: {
          DEFAULT: "#F5EBE8",
          foreground: "#8C7480",
        },
        accent: {
          DEFAULT: "#F6D6E0",
          foreground: "#8A3454",
        },
        destructive: {
          DEFAULT: "#C4453F",
          foreground: "#FFFFFF",
        },
        // Authentication module tokens — kept separate from the
        // chat app's blush/rose system per the auth design spec.
        auth: {
          bg: "#FAF8F5",
          card: "#FFFFFF",
          text: "#2F2F2F",
          muted: "#777777",
          accent: "#8C6A5D",
          border: "#E9E3DE",
          success: "#4CAF50",
          error: "#E53935",
        },
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "Georgia", "serif"],
        sans: ["var(--font-inter)", "system-ui", "sans-serif"],
        mono: ["var(--font-plex-mono)", "monospace"],
        // Auth module typography — modern, rounded, soft, premium.
        quicksand: ["var(--font-quicksand)", "system-ui", "sans-serif"],
        nunito: ["var(--font-nunito)", "system-ui", "sans-serif"],
      },
      borderRadius: {
        lg: "1rem",
        md: "0.75rem",
        sm: "0.5rem",
        bubble: "1.375rem",
      },
      keyframes: {
        "pulse-dot": {
          "0%, 100%": { boxShadow: "0 0 0 0 rgba(110, 156, 130, 0.45)" },
          "50%": { boxShadow: "0 0 0 4px rgba(110, 156, 130, 0)" },
        },
        "fade-slide-up": {
          from: { opacity: "0", transform: "translateY(8px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
      },
      animation: {
        "pulse-dot": "pulse-dot 2.2s ease-in-out infinite",
        "fade-slide-up": "fade-slide-up 0.4s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};
export default config;
