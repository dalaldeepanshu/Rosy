# Rosy

A warm, calm messaging app front end — chat list, presence, and a bottom-nav
shell — built with Next.js 14 (App Router), Tailwind CSS, shadcn/ui-style
components, and Framer Motion.

## Getting started

```bash
npm install
npm run dev
```

Open http://localhost:3000 — it redirects to `/splash`, then flows through
`welcome → phone → otp → name → loading → /chats` (UI only, no backend).

## Structure

- `src/app` — routes: `(main)` group wraps `chats` and `me` with the bottom nav
- `src/components/ui` — shadcn-style primitives (button, avatar, input, badge, skeleton)
- `src/components/chat` — chat list, list item, avatar w/ presence dot, unread badge, bubble
- `src/components/layout` — top bar, search bar, bottom nav
- `src/components/shared` — empty state, page transition, staggered list animation
- `src/lib/mock-data.ts` — sample chats (no backend wired up yet)

## Design tokens

Colors, type, and motion tokens live in `tailwind.config.ts` and
`src/styles/theme.ts`. Palette is a warm blush/porcelain background with a
rosy-pink primary, deep plum-wine text, sage-green presence dot, and a
warm gold accent for highlights — paired with a Fraunces display face,
Inter for UI text, and IBM Plex Mono for timestamps/badges.
