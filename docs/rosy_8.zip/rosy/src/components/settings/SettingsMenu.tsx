"use client";

import { motion } from "framer-motion";
import { useRouter } from "next/navigation";
import {
  Palette,
  Wallpaper,
  Type,
  Lock,
  CircleHelp,
  Info,
  LogOut,
  ChevronRight,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface SettingsEntry {
  label: string;
  subtitle: string;
  icon: LucideIcon;
  danger?: boolean;
  href?: string;
}

const SETTINGS_ITEMS: SettingsEntry[] = [
  {
    label: "Appearance",
    subtitle: "Customize app appearance",
    icon: Palette,
    href: "/me/settings/personalization",
  },
  {
    label: "Chat Wallpaper",
    subtitle: "Choose your chat background",
    icon: Wallpaper,
  },
  {
    label: "Fonts",
    subtitle: "Choose your favorite font",
    icon: Type,
  },
  {
    label: "Privacy",
    subtitle: "Manage your privacy settings",
    icon: Lock,
  },
  {
    label: "Help",
    subtitle: "Get support",
    icon: CircleHelp,
  },
  {
    label: "About Rosy",
    subtitle: "Version and information",
    icon: Info,
  },
];

const LOGOUT_ITEM: SettingsEntry = {
  label: "Logout",
  subtitle: "Sign out from your account",
  icon: LogOut,
  danger: true,
};

const BASE_DELAY = 0.06;
const STAGGER_DELAY = 0.04;
const ROW_DURATION = 0.2;

function SettingsRow({
  item,
  index,
  isLast,
}: {
  item: SettingsEntry;
  index: number;
  isLast: boolean;
}) {
  const Icon = item.icon;
  const router = useRouter();

  return (
    <motion.button
      type="button"
      onClick={() => {
        if (item.href) router.push(item.href);
      }}
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: ROW_DURATION,
        delay: BASE_DELAY + index * STAGGER_DELAY,
        ease: [0.16, 1, 0.3, 1],
      }}
      className={cn(
        "flex w-full items-center gap-4 px-5 py-4 text-left transition-colors active:bg-blush-soft",
        !isLast && "border-b border-blush-border"
      )}
    >
      <span
        className={cn(
          "flex h-11 w-11 shrink-0 items-center justify-center rounded-full",
          item.danger ? "bg-destructive/10" : "bg-rose-50"
        )}
      >
        <Icon
          className={cn(
            "h-[19px] w-[19px]",
            item.danger ? "text-destructive" : "text-rose-500"
          )}
          strokeWidth={1.75}
        />
      </span>

      <span className="min-w-0 flex-1">
        <span
          className={cn(
            "block text-[15px] font-medium leading-tight",
            item.danger ? "text-destructive/90" : "text-ink"
          )}
        >
          {item.label}
        </span>
        <span className="mt-1 block truncate text-[13px] leading-tight text-ink-muted">
          {item.subtitle}
        </span>
      </span>

      <ChevronRight
        className={cn(
          "h-4 w-4 shrink-0",
          item.danger ? "text-destructive/50" : "text-ink-faint"
        )}
        strokeWidth={2}
      />
    </motion.button>
  );
}

export function SettingsMenu() {
  return (
    <div className="px-4 pb-4 pt-6">
      <div className="overflow-hidden rounded-[20px] bg-surface shadow-[0_2px_16px_rgba(58,37,48,0.06)]">
        {SETTINGS_ITEMS.map((item, index) => (
          <SettingsRow
            key={item.label}
            item={item}
            index={index}
            isLast={index === SETTINGS_ITEMS.length - 1}
          />
        ))}
      </div>

      <div className="mt-6 overflow-hidden rounded-[20px] bg-surface shadow-[0_2px_16px_rgba(58,37,48,0.06)]">
        <SettingsRow
          item={LOGOUT_ITEM}
          index={SETTINGS_ITEMS.length}
          isLast
        />
      </div>
    </div>
  );
}
