import * as React from "react";
import { cn } from "@/lib/utils";

export type AuthInputProps = React.InputHTMLAttributes<HTMLInputElement>;

export const AuthInput = React.forwardRef<HTMLInputElement, AuthInputProps>(
  ({ className, ...props }, ref) => {
    return (
      <input
        ref={ref}
        className={cn(
          "h-[54px] w-full rounded-[18px] border border-auth-border bg-auth-card px-4 font-nunito text-[16px] text-auth-text placeholder:text-auth-muted",
          "transition-colors focus:border-auth-accent focus:outline-none focus:ring-2 focus:ring-auth-accent/15",
          className
        )}
        {...props}
      />
    );
  }
);
AuthInput.displayName = "AuthInput";
