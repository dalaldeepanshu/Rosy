import { cn } from "@/lib/utils";

interface RosyLogoProps {
  size?: "sm" | "md" | "lg";
  showWordmark?: boolean;
  className?: string;
}

const sizeMap = {
  sm: { mark: "h-10 w-10 rounded-[12px] text-base", word: "text-lg" },
  md: { mark: "h-16 w-16 rounded-[18px] text-2xl", word: "text-2xl" },
  lg: { mark: "h-20 w-20 rounded-[22px] text-3xl", word: "text-[28px]" },
};

/**
 * Rosy's mark: a single soft rounded square in the accent color with
 * a lowercase monogram — calm and quiet rather than flashy.
 */
export function RosyLogo({
  size = "md",
  showWordmark = false,
  className,
}: RosyLogoProps) {
  const s = sizeMap[size];

  return (
    <div className={cn("flex flex-col items-center gap-3", className)}>
      <div
        className={cn(
          "flex items-center justify-center bg-auth-accent font-quicksand font-semibold text-white shadow-sm",
          s.mark
        )}
        aria-hidden="true"
      >
        r
      </div>
      {showWordmark && (
        <span
          className={cn(
            "font-quicksand font-semibold tracking-tight text-auth-text",
            s.word
          )}
        >
          Rosy
        </span>
      )}
    </div>
  );
}
