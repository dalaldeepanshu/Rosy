"use client";

import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";

const RESEND_SECONDS = 30;

export function ResendTimer() {
  const [secondsLeft, setSecondsLeft] = useState(RESEND_SECONDS);

  useEffect(() => {
    if (secondsLeft <= 0) return;
    const id = setTimeout(() => setSecondsLeft((s) => s - 1), 1000);
    return () => clearTimeout(id);
  }, [secondsLeft]);

  const canResend = secondsLeft <= 0;

  return (
    <button
      type="button"
      disabled={!canResend}
      onClick={() => setSecondsLeft(RESEND_SECONDS)}
      className={cn(
        "font-nunito text-[14px] transition-colors",
        canResend
          ? "font-medium text-auth-accent"
          : "cursor-not-allowed text-auth-muted"
      )}
    >
      {canResend
        ? "Resend code"
        : `Resend code in 0:${secondsLeft.toString().padStart(2, "0")}`}
    </button>
  );
}
