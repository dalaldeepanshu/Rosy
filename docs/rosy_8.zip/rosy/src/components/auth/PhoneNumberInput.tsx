"use client";

import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

interface PhoneNumberInputProps {
  value: string;
  onChange: (value: string) => void;
  className?: string;
}

/**
 * Country is fixed to India for this module — no country-switching
 * logic, per the auth spec. The pill is presented as a selector for
 * visual completeness but carries no behavior.
 */
export function PhoneNumberInput({
  value,
  onChange,
  className,
}: PhoneNumberInputProps) {
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div className="flex h-[54px] shrink-0 items-center gap-1.5 rounded-[18px] border border-auth-border bg-auth-card px-3.5 font-nunito text-[16px] text-auth-text">
        <span className="text-lg leading-none">🇮🇳</span>
        <span>+91</span>
        <ChevronDown className="h-4 w-4 text-auth-muted" strokeWidth={2} />
      </div>
      <input
        type="tel"
        inputMode="numeric"
        autoComplete="tel-national"
        value={value}
        onChange={(e) => onChange(e.target.value.replace(/[^\d\s]/g, ""))}
        placeholder="98765 43210"
        maxLength={11}
        className="h-[54px] w-full min-w-0 rounded-[18px] border border-auth-border bg-auth-card px-4 font-nunito text-[16px] text-auth-text placeholder:text-auth-muted transition-colors focus:border-auth-accent focus:outline-none focus:ring-2 focus:ring-auth-accent/15"
      />
    </div>
  );
}
