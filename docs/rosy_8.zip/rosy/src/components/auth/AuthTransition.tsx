"use client";

import { motion } from "framer-motion";
import type { ReactNode } from "react";

interface AuthTransitionProps {
  children: ReactNode;
}

export function AuthTransition({ children }: AuthTransitionProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -6 }}
      transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
      className="flex min-h-screen flex-col"
    >
      {children}
    </motion.div>
  );
}
