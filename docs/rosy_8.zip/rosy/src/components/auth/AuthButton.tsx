"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface AuthButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
}

export function AuthButton({
  children,
  className,
  disabled,
  ...props
}: AuthButtonProps) {
  return (
    <motion.button
      type="button"
      whileTap={disabled ? undefined : { scale: 0.97 }}
      transition={{ duration: 0.15, ease: [0.16, 1, 0.3, 1] }}
      disabled={disabled}
      className={cn(
        "h-[54px] w-full rounded-[18px] bg-auth-accent font-nunito text-[16px] font-medium text-white shadow-[0_4px_14px_rgba(140,106,93,0.22)] transition-opacity disabled:cursor-not-allowed disabled:opacity-40",
        className
      )}
      {...props}
    >
      {children}
    </motion.button>
  );
}
