"use client";

import { useState } from "react";
import { Search, Pencil } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { SearchBar } from "@/components/layout/SearchBar";
import { RosyMark } from "@/components/layout/RosyMark";

interface TopBarProps {
  title: string;
  searchValue?: string;
  onSearchChange?: (value: string) => void;
  showSearch?: boolean;
  showLogo?: boolean;
  showEdit?: boolean;
  onEditClick?: () => void;
  onSearchClick?: () => void;
}

export function TopBar({
  title,
  searchValue = "",
  onSearchChange,
  showSearch = false,
  showLogo = false,
  showEdit = false,
  onEditClick,
  onSearchClick,
}: TopBarProps) {
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <header className="sticky top-0 z-10 border-b border-blush-border bg-blush/90 px-4 pb-3 pt-4 backdrop-blur-md">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {showLogo && <RosyMark />}
          <h1 className="font-display text-[26px] font-semibold tracking-tight text-ink">
            {title}
          </h1>
        </div>
        {showSearch && (
          <button
            type="button"
            onClick={() =>
              onSearchClick ? onSearchClick() : setSearchOpen((prev) => !prev)
            }
            className="flex h-9 w-9 items-center justify-center rounded-full text-rose-500 transition-colors hover:bg-rose-100"
            aria-label="Toggle search"
          >
            <Search className="h-5 w-5" strokeWidth={2} />
          </button>
        )}
        {showEdit && (
          <button
            type="button"
            onClick={onEditClick}
            className="flex h-9 w-9 items-center justify-center rounded-full text-rose-500 transition-colors hover:bg-rose-100"
            aria-label="Edit profile"
          >
            <Pencil className="h-[18px] w-[18px]" strokeWidth={2} />
          </button>
        )}
      </div>

      <AnimatePresence initial={false}>
        {showSearch && searchOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
            className="overflow-hidden"
          >
            <SearchBar
              value={searchValue}
              onChange={(v) => onSearchChange?.(v)}
              className="mt-3"
            />
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
