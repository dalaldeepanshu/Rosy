export function RosyMark({ className }: { className?: string }) {
  return (
    <div
      className={
        "flex h-8 w-8 shrink-0 items-center justify-center rounded-[10px] bg-gradient-to-br from-rose-300 to-rose-500 font-display text-sm font-semibold text-white " +
        (className ?? "")
      }
      aria-hidden="true"
    >
      r
    </div>
  );
}
