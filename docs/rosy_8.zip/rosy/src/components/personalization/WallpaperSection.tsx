"use client";

import { useState, type CSSProperties } from "react";
import { motion } from "framer-motion";
import { Check, ImagePlus } from "lucide-react";
import { mockWallpapers, type WallpaperPattern } from "@/lib/mock-wallpapers";
import { cn } from "@/lib/utils";

const CARD_DURATION = 0.2;
const CARD_STAGGER = 0.025;

function patternStyle(pattern: WallpaperPattern): CSSProperties {
  switch (pattern) {
    case "dots":
      return {
        backgroundImage: "radial-gradient(rgba(58,37,48,0.14) 1.5px, transparent 1.5px)",
        backgroundSize: "10px 10px",
      };
    case "grid":
      return {
        backgroundImage:
          "linear-gradient(rgba(58,37,48,0.10) 1px, transparent 1px), linear-gradient(90deg, rgba(58,37,48,0.10) 1px, transparent 1px)",
        backgroundSize: "12px 12px",
      };
    case "waves":
      return {
        backgroundImage:
          "repeating-linear-gradient(120deg, rgba(58,37,48,0.10) 0px, rgba(58,37,48,0.10) 2px, transparent 2px, transparent 10px)",
      };
    case "petals":
      return {
        backgroundImage: "radial-gradient(rgba(58,37,48,0.12) 2.5px, transparent 2.5px)",
        backgroundSize: "16px 16px",
      };
    case "solid":
    default:
      return {};
  }
}

export function WallpaperSection() {
  const [selectedId, setSelectedId] = useState(mockWallpapers[0].id);

  return (
    <section className="px-4 pt-8">
      <h2 className="font-display text-lg font-semibold text-ink">
        Chat Wallpapers
      </h2>
      <p className="mt-1 text-[13px] text-ink-muted">
        Choose a background for your conversations. Preview only.
      </p>

      <div className="mt-4 grid grid-cols-3 gap-3">
        {mockWallpapers.map((wallpaper, index) => {
          const isSelected = wallpaper.id === selectedId;
          return (
            <motion.button
              key={wallpaper.id}
              type="button"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: CARD_DURATION,
                delay: index * CARD_STAGGER,
                ease: [0.16, 1, 0.3, 1],
              }}
              onClick={() => setSelectedId(wallpaper.id)}
              className={cn(
                "relative overflow-hidden rounded-[16px] shadow-[0_2px_16px_rgba(58,37,48,0.06)] transition-transform active:scale-[0.96]",
                isSelected && "ring-2 ring-rose-500"
              )}
            >
              <div
                className="h-20 w-full"
                style={{
                  background: `linear-gradient(160deg, ${wallpaper.gradient[0]}, ${wallpaper.gradient[1]})`,
                  ...patternStyle(wallpaper.pattern),
                }}
              />
              <span className="absolute inset-x-0 bottom-0 truncate bg-black/25 px-2 py-1 text-[11px] font-medium text-white">
                {wallpaper.name}
              </span>
              {isSelected && (
                <span className="absolute right-1.5 top-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500">
                  <Check className="h-2.5 w-2.5 text-white" strokeWidth={3} />
                </span>
              )}
            </motion.button>
          );
        })}

        <motion.button
          type="button"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{
            duration: CARD_DURATION,
            delay: mockWallpapers.length * CARD_STAGGER,
            ease: [0.16, 1, 0.3, 1],
          }}
          className="flex h-20 flex-col items-center justify-center gap-1 rounded-[16px] border border-dashed border-blush-border bg-blush-soft/60 text-ink-muted transition-colors active:bg-blush-soft"
        >
          <ImagePlus className="h-5 w-5" strokeWidth={1.75} />
          <span className="text-[11px] font-medium">Choose from Gallery</span>
        </motion.button>
      </div>
    </section>
  );
}
