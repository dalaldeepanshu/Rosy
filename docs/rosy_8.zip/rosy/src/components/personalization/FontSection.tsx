"use client";

import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { useFontSelection } from "@/hooks/useFontSelection";
import { cn } from "@/lib/utils";

const PREVIEW_TEXT = "Hello! Welcome to Rosy 🌹";
const ROW_DURATION = 0.2;
const ROW_STAGGER = 0.012;

export function FontSection() {
  const { fonts, selectedFontId, selectedFont, selectFont } = useFontSelection();

  return (
    <section className="px-4 pt-8">
      <h2 className="font-display text-lg font-semibold text-ink">Fonts</h2>
      <p className="mt-1 text-[13px] text-ink-muted">
        Choose your favorite font
      </p>

      {/* Live preview — updates only here, never applied app-wide yet */}
      <div className="mt-4 overflow-hidden rounded-[18px] bg-surface px-5 py-6 text-center shadow-[0_2px_16px_rgba(58,37,48,0.06)]">
        <p
          className="text-xl leading-snug text-ink"
          style={{
            fontFamily: selectedFont.cssFontFamily,
            fontStyle: selectedFont.italic ? "italic" : "normal",
            fontWeight: selectedFont.weight ?? 400,
          }}
        >
          {PREVIEW_TEXT}
        </p>
        <p className="mt-2 text-xs font-medium uppercase tracking-wide text-ink-faint">
          {selectedFont.name}
        </p>
      </div>

      <p className="mt-6 px-1 text-xs font-medium uppercase tracking-wide text-ink-faint">
        Top 100 Fonts
      </p>

      <div className="mt-2 max-h-[420px] overflow-y-auto overflow-x-hidden overscroll-contain rounded-[18px] bg-surface shadow-[0_2px_16px_rgba(58,37,48,0.06)]">
        {fonts.map((font, index) => {
          const isSelected = font.id === selectedFontId;
          return (
            <motion.button
              key={font.id}
              type="button"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{
                duration: ROW_DURATION,
                delay: Math.min(index * ROW_STAGGER, 0.3),
                ease: [0.16, 1, 0.3, 1],
              }}
              onClick={() => selectFont(font.id)}
              className={cn(
                "flex w-full items-center justify-between gap-3 border-b border-blush-border px-5 py-3.5 text-left transition-colors last:border-b-0 active:bg-blush-soft",
                isSelected && "bg-rose-50"
              )}
            >
              <span
                className="truncate text-[15px] text-ink"
                style={{
                  fontFamily: font.cssFontFamily,
                  fontStyle: font.italic ? "italic" : "normal",
                  fontWeight: font.weight ?? 400,
                }}
              >
                {font.name}
              </span>

              {isSelected && (
                <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-rose-500">
                  <Check className="h-3 w-3 text-white" strokeWidth={3} />
                </span>
              )}
            </motion.button>
          );
        })}
      </div>
    </section>
  );
}
