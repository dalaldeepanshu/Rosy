"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { mockThemes } from "@/lib/mock-themes";
import { cn } from "@/lib/utils";

const CARD_DURATION = 0.2;
const CARD_STAGGER = 0.025;

export function ThemeSection() {
  const [selectedId, setSelectedId] = useState(mockThemes[0].id);

  return (
    <section className="px-4 pt-6">
      <h2 className="font-display text-lg font-semibold text-ink">Themes</h2>
      <p className="mt-1 text-[13px] text-ink-muted">
        Pick a look for Rosy. Preview only — nothing is applied yet.
      </p>

      <div className="mt-4 grid grid-cols-2 gap-3.5">
        {mockThemes.map((theme, index) => {
          const isSelected = theme.id === selectedId;
          return (
            <motion.button
              key={theme.id}
              type="button"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: CARD_DURATION,
                delay: index * CARD_STAGGER,
                ease: [0.16, 1, 0.3, 1],
              }}
              onClick={() => setSelectedId(theme.id)}
              className={cn(
                "group relative overflow-hidden rounded-[18px] bg-surface p-2.5 text-left shadow-[0_2px_16px_rgba(58,37,48,0.06)] transition-transform active:scale-[0.98]",
                isSelected && "ring-2 ring-rose-500"
              )}
            >
              <div
                className="h-16 w-full rounded-[12px]"
                style={{
                  background: `linear-gradient(135deg, ${theme.gradient[0]} 0%, ${theme.gradient[1]} 55%, ${theme.gradient[2]} 100%)`,
                }}
              />
              <div className="mt-2 flex items-center justify-between gap-2 px-0.5">
                <span className="truncate text-[13px] font-medium text-ink">
                  {theme.name}
                </span>
                {isSelected && (
                  <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-rose-500">
                    <Check className="h-2.5 w-2.5 text-white" strokeWidth={3} />
                  </span>
                )}
              </div>
            </motion.button>
          );
        })}
      </div>
    </section>
  );
}
