"use client";

import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";

/**
 * Header for the Personalization screen — a left-aligned back button
 * with a centered title, matching the chrome established by other
 * secondary screens (see SettingsHeader / SearchHeader).
 */
export function PersonalizationHeader() {
  const router = useRouter();

  return (
    <header className="sticky top-0 z-20 flex items-center justify-between border-b border-blush-border bg-blush/95 px-3 py-3 backdrop-blur-md">
      <button
        type="button"
        onClick={() => router.back()}
        aria-label="Go back"
        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-ink transition-colors hover:bg-blush-soft active:bg-blush-soft"
      >
        <ArrowLeft className="h-5 w-5" strokeWidth={2} />
      </button>

      <h1 className="font-display text-[19px] font-semibold tracking-tight text-ink">
        Personalization
      </h1>

      {/* Spacer to balance the back button so the title stays centered */}
      <div className="h-10 w-10 shrink-0" aria-hidden="true" />
    </header>
  );
}
