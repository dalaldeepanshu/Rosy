import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description?: string;
  className?: string;
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  className,
}: EmptyStateProps) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center gap-3 px-8 py-20 text-center",
        className
      )}
    >
      <div className="flex h-14 w-14 items-center justify-center rounded-full bg-rose-100">
        <Icon className="h-6 w-6 text-rose-500" strokeWidth={1.75} />
      </div>
      <p className="font-display text-lg text-ink">{title}</p>
      {description && (
        <p className="max-w-[26ch] text-sm text-ink-muted">{description}</p>
      )}
    </div>
  );
}
