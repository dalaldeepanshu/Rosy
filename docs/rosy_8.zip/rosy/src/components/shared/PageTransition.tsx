"use client";

import { motion } from "framer-motion";
import type { ReactNode } from "react";
import { ANIMATION } from "@/lib/constants";

interface PageTransitionProps {
  children: ReactNode;
}

/**
 * Wraps a page's content in a gentle fade + rise so route changes
 * feel like a soft hand-off rather than a hard cut.
 */
export function PageTransition({ children }: PageTransitionProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -6 }}
      transition={{
        duration: ANIMATION.pageDuration,
        ease: [0.16, 1, 0.3, 1],
      }}
    >
      {children}
    </motion.div>
  );
}
