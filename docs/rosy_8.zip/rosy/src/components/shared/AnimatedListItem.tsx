"use client";

import { motion } from "framer-motion";
import type { ReactNode } from "react";
import { ANIMATION } from "@/lib/constants";

interface AnimatedListItemProps {
  children: ReactNode;
  index: number;
}

/**
 * Fades and slides a single row into place, staggered by its index
 * within the list. Used for the chat list so rows cascade in on load.
 */
export function AnimatedListItem({ children, index }: AnimatedListItemProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: ANIMATION.listItemDuration,
        delay: index * ANIMATION.staggerDelay,
        ease: [0.16, 1, 0.3, 1],
      }}
    >
      {children}
    </motion.div>
  );
}
