import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";

interface ChatAvatarProps {
  name: string;
  avatarUrl?: string;
  avatarColor?: string;
  isOnline?: boolean;
  size?: "sm" | "md" | "lg";
}

const sizeMap = {
  sm: "h-10 w-10",
  md: "h-14 w-14",
  lg: "h-16 w-16",
};

function initials(name: string) {
  return name
    .split(" ")
    .map((part) => part[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

export function ChatAvatar({
  name,
  avatarUrl,
  avatarColor = "from-rose-300 to-rose-500",
  isOnline,
  size = "md",
}: ChatAvatarProps) {
  return (
    <div className="relative shrink-0">
      <Avatar className={cn(sizeMap[size], "ring-2 ring-white")}>
        {avatarUrl && <AvatarImage src={avatarUrl} alt={name} />}
        <AvatarFallback
          className={cn("bg-gradient-to-br", avatarColor)}
        >
          {initials(name)}
        </AvatarFallback>
      </Avatar>
      {isOnline && (
        <span className="absolute bottom-0 right-0 flex h-3.5 w-3.5 items-center justify-center">
          <span className="absolute h-3.5 w-3.5 animate-pulse-dot rounded-full" />
          <span className="h-2.5 w-2.5 rounded-full border-2 border-white bg-sage" />
        </span>
      )}
    </div>
  );
}
