import { ChatAvatar } from "@/components/chat/ChatAvatar";
import { UnreadBadge } from "@/components/chat/UnreadBadge";
import { cn, formatChatTimestamp } from "@/lib/utils";
import type { Chat } from "@/types/chat";

interface ChatListItemProps {
  chat: Chat;
}

export function ChatListItem({ chat }: ChatListItemProps) {
  return (
    <button
      type="button"
      className="flex min-h-[76px] w-full items-center gap-3 px-4 py-3 text-left transition-colors active:bg-blush-soft"
    >
      <ChatAvatar
        name={chat.name}
        avatarUrl={chat.avatarUrl}
        avatarColor={chat.avatarColor}
        isOnline={chat.isOnline}
        size="md"
      />

      <div className="flex min-w-0 flex-1 items-start justify-between gap-2 border-b border-blush-border pb-3 pt-0.5">
        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between gap-2">
            <span className="truncate font-display text-[15px] font-medium text-ink">
              {chat.name}
            </span>
            <span
              className={cn(
                "shrink-0 font-mono text-[11px]",
                chat.unreadCount > 0 ? "text-rose-500" : "text-ink-faint"
              )}
            >
              {formatChatTimestamp(chat.lastMessageTimestamp)}
            </span>
          </div>

          <div className="mt-1 flex items-start justify-between gap-2">
            <span
              className={cn(
                "line-clamp-2 text-sm leading-snug",
                chat.isTyping ? "italic text-rose-500" : "text-ink-muted"
              )}
            >
              {chat.lastMessage}
            </span>
            <UnreadBadge
              count={chat.unreadCount}
              className="mt-0.5 shrink-0"
            />
          </div>
        </div>
      </div>
    </button>
  );
}
