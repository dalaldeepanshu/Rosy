import { Skeleton } from "@/components/ui/skeleton";

function ChatListItemSkeleton() {
  return (
    <div className="flex min-h-[76px] w-full items-center gap-3 px-4 py-3">
      <Skeleton className="h-14 w-14 shrink-0 rounded-full" />
      <div className="flex-1 border-b border-blush-border pb-3 pt-0.5">
        <div className="flex items-center justify-between gap-2">
          <Skeleton className="h-3.5 w-28 rounded-sm" />
          <Skeleton className="h-3 w-8 rounded-sm" />
        </div>
        <Skeleton className="mt-2.5 h-3 w-48 max-w-full rounded-sm" />
      </div>
    </div>
  );
}

export function ChatListSkeleton({ rows = 7 }: { rows?: number }) {
  return (
    <div className="flex flex-col">
      {Array.from({ length: rows }).map((_, index) => (
        <ChatListItemSkeleton key={index} />
      ))}
    </div>
  );
}
