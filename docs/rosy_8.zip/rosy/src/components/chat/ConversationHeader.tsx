"use client";

import { useRouter } from "next/navigation";
import { ArrowLeft, MoreVertical } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import type { ConversationProfile } from "@/types/conversation";

function initials(name: string) {
  return name
    .split(" ")
    .map((part) => part[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

export function ConversationHeader({
  profile,
}: {
  profile: ConversationProfile;
}) {
  const router = useRouter();

  return (
    <header className="sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-blush-border bg-blush/95 px-3 py-2.5 backdrop-blur-md">
      <div className="flex min-w-0 items-center gap-2">
        <button
          type="button"
          onClick={() => router.back()}
          aria-label="Go back"
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-ink transition-colors hover:bg-blush-soft"
        >
          <ArrowLeft className="h-5 w-5" strokeWidth={2} />
        </button>

        <Avatar className="h-12 w-12 shrink-0 ring-2 ring-white">
          <AvatarFallback
            className={cn("bg-gradient-to-br", profile.avatarColor)}
          >
            {initials(profile.name)}
          </AvatarFallback>
        </Avatar>

        <div className="min-w-0">
          <p className="truncate font-display text-[16px] font-medium text-ink">
            {profile.name}
          </p>
          <p
            className={cn(
              "truncate text-xs",
              profile.isOnline ? "text-sage" : "text-ink-faint"
            )}
          >
            {profile.lastSeenLabel}
          </p>
        </div>
      </div>

      <button
        type="button"
        aria-label="More options"
        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-ink transition-colors hover:bg-blush-soft"
      >
        <MoreVertical className="h-5 w-5" strokeWidth={2} />
      </button>
    </header>
  );
}
