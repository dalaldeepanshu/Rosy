"use client";

import { useEffect, useRef } from "react";
import { Smile, Paperclip, Send } from "lucide-react";
import { AnimatePresence } from "framer-motion";
import { ReplyPreviewBar } from "@/components/chat/ReplyPreviewBar";
import type { ReplyReference } from "@/types/conversation";

const LINE_HEIGHT_PX = 22;
const MAX_LINES = 6;

interface MessageInputProps {
  value: string;
  onChange: (value: string) => void;
  onSend: () => void;
  replyTo: ReplyReference | null;
  onCancelReply: () => void;
}

export function MessageInput({
  value,
  onChange,
  onSend,
  replyTo,
  onCancelReply,
}: MessageInputProps) {
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    const maxHeight = LINE_HEIGHT_PX * MAX_LINES;
    el.style.height = `${Math.min(el.scrollHeight, maxHeight)}px`;
  }, [value]);

  function handleSend() {
    if (!value.trim()) return;
    onSend();
  }

  return (
    <div className="sticky bottom-0 z-20 border-t border-blush-border bg-blush/95 backdrop-blur-md">
      <AnimatePresence initial={false}>
        {replyTo && (
          <ReplyPreviewBar reply={replyTo} onCancel={onCancelReply} />
        )}
      </AnimatePresence>

      <div className="flex items-end gap-2 px-3 py-2.5">
        <button
          type="button"
          aria-label="Emoji"
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-ink-muted transition-colors hover:bg-blush-soft"
        >
          <Smile className="h-6 w-6" strokeWidth={1.75} />
        </button>

        <button
          type="button"
          aria-label="Attach image"
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-ink-muted transition-colors hover:bg-blush-soft"
        >
          <Paperclip className="h-6 w-6" strokeWidth={1.75} />
        </button>

        <textarea
          ref={textareaRef}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              handleSend();
            }
          }}
          rows={1}
          placeholder="Message"
          className="max-h-[132px] min-h-[44px] flex-1 resize-none rounded-[22px] border border-transparent bg-blush-soft px-4 py-2.5 font-sans text-[15px] leading-[22px] text-ink placeholder:text-ink-faint focus:border-rose-300 focus:outline-none"
        />

        <button
          type="button"
          onClick={handleSend}
          disabled={!value.trim()}
          aria-label="Send message"
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-rose-500 text-white transition-opacity disabled:cursor-not-allowed disabled:opacity-40"
        >
          <Send className="h-[18px] w-[18px]" strokeWidth={2.25} />
        </button>
      </div>
    </div>
  );
}
