"use client";

import { X } from "lucide-react";
import { motion } from "framer-motion";
import type { ReplyReference } from "@/types/conversation";

interface ReplyPreviewBarProps {
  reply: ReplyReference;
  onCancel: () => void;
}

export function ReplyPreviewBar({ reply, onCancel }: ReplyPreviewBarProps) {
  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: "auto" }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="overflow-hidden"
    >
      <div className="mx-4 mb-2 flex items-center justify-between gap-3 rounded-2xl bg-rose-50 px-3.5 py-2.5">
        <div className="min-w-0 flex-1">
          <p className="text-xs font-semibold text-rose-600">
            Replying to {reply.senderLabel}
          </p>
          <p className="truncate text-xs text-ink-muted">{reply.preview}</p>
        </div>
        <button
          type="button"
          onClick={onCancel}
          aria-label="Cancel reply"
          className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-ink-faint transition-colors hover:bg-rose-100 hover:text-rose-600"
        >
          <X className="h-3.5 w-3.5" strokeWidth={2} />
        </button>
      </div>
    </motion.div>
  );
}
