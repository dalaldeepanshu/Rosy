import { ChatIllustrationPlaceholder } from "@/components/chat/ChatIllustrationPlaceholder";

export function EmptyChats() {
  return (
    <div className="flex flex-col items-center justify-center gap-4 px-8 py-20 text-center">
      <ChatIllustrationPlaceholder />
      <div className="flex flex-col gap-1.5">
        <p className="font-display text-lg text-ink">No conversations yet</p>
        <p className="max-w-[26ch] text-sm text-ink-muted">
          Start chatting with your friends.
        </p>
      </div>
    </div>
  );
}
