"use client";

import { AnimatePresence, motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface DeleteMessageSheetProps {
  open: boolean;
  onClose: () => void;
}

const options = [
  { label: "Delete for Me", tone: "default" as const },
  { label: "Delete for Everyone", tone: "danger" as const },
];

export function DeleteMessageSheet({ open, onClose }: DeleteMessageSheetProps) {
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="fixed inset-0 z-30 bg-ink/30"
          />
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
            className="fixed inset-x-0 bottom-0 z-40 mx-auto w-full max-w-md rounded-t-[24px] bg-surface p-2 pb-[max(1rem,env(safe-area-inset-bottom))]"
          >
            <div className="mx-auto mb-2 mt-1 h-1 w-10 rounded-full bg-blush-border" />
            <div className="overflow-hidden rounded-2xl">
              {options.map((option) => (
                <button
                  key={option.label}
                  type="button"
                  onClick={onClose}
                  className={cn(
                    "flex w-full items-center border-b border-blush-border px-4 py-3.5 text-left text-[15px] font-medium last:border-b-0 active:bg-blush-soft",
                    option.tone === "danger" ? "text-destructive" : "text-ink"
                  )}
                >
                  {option.label}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={onClose}
              className="mt-2 w-full rounded-2xl bg-blush-soft px-4 py-3.5 text-center text-[15px] font-medium text-ink-muted active:bg-blush-border"
            >
              Cancel
            </button>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
