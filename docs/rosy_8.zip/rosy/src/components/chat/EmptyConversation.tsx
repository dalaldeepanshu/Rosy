export function EmptyConversation() {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-2 px-8 py-20 text-center">
      <p className="font-display text-lg text-ink">
        Start your conversation 🌹
      </p>
    </div>
  );
}
