import { cn } from "@/lib/utils";

interface ChatBubbleProps {
  text: string;
  isOwn?: boolean;
  timestamp?: string;
}

/**
 * Rosy's signature bubble: mostly rounded, but the corner nearest the
 * sender's avatar pulls in tight — an asymmetric, hand-passed-note
 * shape rather than the generic uniform-radius bubble.
 */
export function ChatBubble({ text, isOwn = false, timestamp }: ChatBubbleProps) {
  return (
    <div
      className={cn(
        "flex w-full",
        isOwn ? "justify-end" : "justify-start"
      )}
    >
      <div
        className={cn(
          "max-w-[75%] px-4 py-2.5 text-sm leading-relaxed shadow-sm",
          isOwn
            ? "rounded-bubble rounded-br-md bg-rose-500 text-white"
            : "rounded-bubble rounded-bl-md bg-surface text-ink"
        )}
      >
        <p>{text}</p>
        {timestamp && (
          <span
            className={cn(
              "mt-1 block font-mono text-[10px] tracking-wide",
              isOwn ? "text-rose-100" : "text-ink-faint"
            )}
          >
            {timestamp}
          </span>
        )}
      </div>
    </div>
  );
}
