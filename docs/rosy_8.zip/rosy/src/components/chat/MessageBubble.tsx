"use client";

import { useRef } from "react";
import { CheckCheck, Check } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import type { ConversationMessage } from "@/types/conversation";

interface MessageBubbleProps {
  message: ConversationMessage;
  onLongPress: (message: ConversationMessage) => void;
  onTapReply: (message: ConversationMessage) => void;
}

const LONG_PRESS_MS = 480;

function formatTime(iso: string): string {
  return new Date(iso).toLocaleTimeString(undefined, {
    hour: "numeric",
    minute: "2-digit",
  });
}

export function MessageBubble({
  message,
  onLongPress,
  onTapReply,
}: MessageBubbleProps) {
  const isOwn = message.sender === "me";
  const pressTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const longPressed = useRef(false);

  function startPress() {
    longPressed.current = false;
    pressTimer.current = setTimeout(() => {
      longPressed.current = true;
      onLongPress(message);
    }, LONG_PRESS_MS);
  }

  function endPress() {
    if (pressTimer.current) clearTimeout(pressTimer.current);
    if (!longPressed.current) {
      onTapReply(message);
    }
  }

  function cancelPress() {
    if (pressTimer.current) clearTimeout(pressTimer.current);
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className={cn("flex w-full px-4", isOwn ? "justify-end" : "justify-start")}
    >
      <button
        type="button"
        onPointerDown={startPress}
        onPointerUp={endPress}
        onPointerLeave={cancelPress}
        className={cn(
          "max-w-[75%] select-none rounded-[24px] px-4 py-2.5 text-left shadow-sm",
          isOwn ? "bg-rose-500 text-white" : "bg-surface text-ink",
          message.kind === "image" && "overflow-hidden p-1.5"
        )}
      >
        {message.replyTo && (
          <div
            className={cn(
              "mb-1.5 rounded-2xl px-3 py-1.5",
              isOwn ? "bg-white/15" : "bg-blush-soft"
            )}
          >
            <p
              className={cn(
                "text-[11px] font-semibold",
                isOwn ? "text-white" : "text-rose-600"
              )}
            >
              {message.replyTo.senderLabel}
            </p>
            <p
              className={cn(
                "truncate text-[11px]",
                isOwn ? "text-rose-50/85" : "text-ink-muted"
              )}
            >
              {message.replyTo.preview}
            </p>
          </div>
        )}

        {message.kind === "image" && message.imageUrl ? (
          <div className="relative aspect-[4/3] w-56 max-w-full overflow-hidden rounded-[18px]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={message.imageUrl}
              alt="Shared image"
              className="h-full w-full object-cover"
            />
          </div>
        ) : (
          <p className="whitespace-pre-wrap break-words text-[15px] leading-relaxed">
            {message.text}
          </p>
        )}

        <div
          className={cn(
            "mt-1 flex items-center justify-end gap-1",
            message.kind === "image" && "px-1.5 pb-1"
          )}
        >
          <span
            className={cn(
              "font-mono text-[10px] tracking-wide",
              isOwn ? "text-rose-100" : "text-ink-faint"
            )}
          >
            {formatTime(message.timestamp)}
          </span>
          {isOwn &&
            (message.status === "sent" ? (
              <Check className="h-3.5 w-3.5 text-rose-100" strokeWidth={2.25} />
            ) : (
              <CheckCheck
                className="h-3.5 w-3.5 text-rose-100"
                strokeWidth={2.25}
              />
            ))}
        </div>
      </button>
    </motion.div>
  );
}
