import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface UnreadBadgeProps {
  count: number;
  muted?: boolean;
  className?: string;
}

export function UnreadBadge({ count, muted, className }: UnreadBadgeProps) {
  if (count <= 0) return null;

  return (
    <Badge
      variant={muted ? "muted" : "default"}
      className={cn("h-5 min-w-[1.25rem] px-1.5 font-mono", className)}
    >
      {count > 99 ? "99+" : count}
    </Badge>
  );
}
