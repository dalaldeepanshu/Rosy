"use client";

import { motion } from "framer-motion";
import { MessageCircleDashed } from "lucide-react";
import { ChatListItem } from "@/components/chat/ChatListItem";
import { EmptyChats } from "@/components/chat/EmptyChats";
import { EmptyState } from "@/components/shared/EmptyState";
import type { Chat } from "@/types/chat";

interface ChatListProps {
  chats: Chat[];
  totalChatCount: number;
}

const ROW_DURATION = 0.2;
const ROW_STAGGER = 0.03;

export function ChatList({ chats, totalChatCount }: ChatListProps) {
  if (totalChatCount === 0) {
    return <EmptyChats />;
  }

  if (chats.length === 0) {
    return (
      <EmptyState
        icon={MessageCircleDashed}
        title="No chats found"
        description="Try a different name or start a new conversation."
      />
    );
  }

  return (
    <div className="flex flex-col">
      {chats.map((chat, index) => (
        <motion.div
          key={chat.id}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{
            duration: ROW_DURATION,
            delay: index * ROW_STAGGER,
            ease: [0.16, 1, 0.3, 1],
          }}
        >
          <ChatListItem chat={chat} />
        </motion.div>
      ))}
    </div>
  );
}
