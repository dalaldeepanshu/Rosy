export function ChatIllustrationPlaceholder() {
  return (
    <svg
      width="112"
      height="112"
      viewBox="0 0 112 112"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <circle cx="56" cy="56" r="56" fill="#FCEEF2" />
      <path
        d="M32 46c0-9.941 10.745-18 24-18s24 8.059 24 18-10.745 18-24 18a27.6 27.6 0 0 1-7.2-.94L38 68l1.86-10.86C34.63 53.63 32 50 32 46Z"
        fill="#F6D6E0"
        stroke="#E58FA8"
        strokeWidth="2"
        strokeLinejoin="round"
      />
      <circle cx="47" cy="46" r="2.5" fill="#C9587A" />
      <circle cx="56" cy="46" r="2.5" fill="#C9587A" />
      <circle cx="65" cy="46" r="2.5" fill="#C9587A" />
    </svg>
  );
}
