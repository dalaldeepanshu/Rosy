"use client";

import { motion } from "framer-motion";

interface ProfileCardRow {
  label: string;
  value: string;
}

interface ProfileCardProps {
  name: string;
  phone: string;
  bio: string;
}

export function ProfileCard({ name, phone, bio }: ProfileCardProps) {
  const rows: ProfileCardRow[] = [
    { label: "Display Name", value: name },
    { label: "Phone Number", value: phone },
    { label: "Bio", value: bio },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, delay: 0.05, ease: [0.16, 1, 0.3, 1] }}
      className="mx-4 mt-8 overflow-hidden rounded-[20px] bg-surface shadow-[0_2px_16px_rgba(58,37,48,0.06)]"
    >
      {rows.map((row, index) => (
        <div
          key={row.label}
          className={
            index < rows.length - 1
              ? "border-b border-blush-border px-5 py-4"
              : "px-5 py-4"
          }
        >
          <p className="text-xs font-medium uppercase tracking-wide text-ink-faint">
            {row.label}
          </p>
          <p className="mt-1.5 text-[15px] leading-relaxed text-ink">
            {row.value}
          </p>
        </div>
      ))}
    </motion.div>
  );
}
