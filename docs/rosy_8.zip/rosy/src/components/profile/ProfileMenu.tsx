"use client";

import { motion } from "framer-motion";
import {
  User,
  Lock,
  Palette,
  CircleHelp,
  Info,
  ChevronRight,
  type LucideIcon,
} from "lucide-react";

interface MenuEntry {
  label: string;
  icon: LucideIcon;
}

const MENU_ITEMS: MenuEntry[] = [
  { label: "Profile", icon: User },
  { label: "Privacy", icon: Lock },
  { label: "Appearance", icon: Palette },
  { label: "Help", icon: CircleHelp },
  { label: "About Rosy", icon: Info },
];

const STAGGER_DELAY = 0.03;
const BASE_DELAY = 0.1;

export function ProfileMenu() {
  return (
    <div className="mx-4 mt-6 overflow-hidden rounded-[20px] bg-surface shadow-[0_2px_16px_rgba(58,37,48,0.06)]">
      {MENU_ITEMS.map((item, index) => {
        const Icon = item.icon;
        return (
          <motion.button
            key={item.label}
            type="button"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.2,
              delay: BASE_DELAY + index * STAGGER_DELAY,
              ease: [0.16, 1, 0.3, 1],
            }}
            className="flex w-full items-center gap-3.5 border-b border-blush-border px-5 py-4 text-left last:border-b-0 active:bg-blush-soft"
          >
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-rose-50">
              <Icon className="h-[18px] w-[18px] text-rose-500" strokeWidth={1.75} />
            </span>
            <span className="flex-1 text-[15px] text-ink">{item.label}</span>
            <ChevronRight className="h-4 w-4 text-ink-faint" strokeWidth={2} />
          </motion.button>
        );
      })}
    </div>
  );
}
