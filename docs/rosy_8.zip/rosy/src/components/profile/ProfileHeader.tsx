"use client";

import { motion } from "framer-motion";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface ProfileHeaderProps {
  name: string;
  phone: string;
  bio: string;
  avatarUrl: string;
}

export function ProfileHeader({
  name,
  phone,
  bio,
  avatarUrl,
}: ProfileHeaderProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="flex flex-col items-center gap-4 px-6 pt-8 text-center"
    >
      <Avatar className="h-24 w-24 ring-4 ring-white shadow-sm">
        <AvatarImage src={avatarUrl} alt={name} />
        <AvatarFallback className="bg-gradient-to-br from-rose-300 to-rose-500 text-2xl">
          {name.slice(0, 2).toUpperCase()}
        </AvatarFallback>
      </Avatar>

      <div className="flex flex-col gap-1.5">
        <p className="font-display text-2xl font-semibold tracking-tight text-ink">
          {name}
        </p>
        <p className="font-mono text-sm text-ink-muted">{phone}</p>
        <p className="max-w-[28ch] text-sm leading-relaxed text-ink-muted">
          {bio}
        </p>
      </div>
    </motion.div>
  );
}
