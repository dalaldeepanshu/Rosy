"use client";

import { motion } from "framer-motion";
import { SearchX } from "lucide-react";
import { ChatListItem } from "@/components/chat/ChatListItem";
import { EmptyState } from "@/components/shared/EmptyState";
import type { Chat } from "@/types/chat";

const ROW_DURATION = 0.2;
const ROW_STAGGER = 0.03;

interface SearchResultsListProps {
  results: Chat[];
}

export function SearchResultsList({ results }: SearchResultsListProps) {
  if (results.length === 0) {
    return (
      <EmptyState
        icon={SearchX}
        title="No results found"
        description="Try searching with a different keyword."
        className="pt-16"
      />
    );
  }

  return (
    <div className="flex flex-col">
      {results.map((chat, index) => (
        <motion.div
          key={chat.id}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{
            duration: ROW_DURATION,
            delay: index * ROW_STAGGER,
            ease: [0.16, 1, 0.3, 1],
          }}
        >
          <ChatListItem chat={chat} />
        </motion.div>
      ))}
    </div>
  );
}
