"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Clock, X } from "lucide-react";
import { mockRecentSearches } from "@/lib/mock-recent-searches";

const MAX_RECENT_ITEMS = 5;
const ROW_DURATION = 0.2;
const ROW_STAGGER = 0.03;

interface RecentSearchesProps {
  onSelect: (term: string) => void;
}

export function RecentSearches({ onSelect }: RecentSearchesProps) {
  const [items, setItems] = useState<string[]>(
    mockRecentSearches.slice(0, MAX_RECENT_ITEMS)
  );

  if (items.length === 0) {
    return null;
  }

  return (
    <div className="px-4 pt-2">
      <p className="px-1 pb-2 text-xs font-medium uppercase tracking-wide text-ink-faint">
        Recent Searches
      </p>

      <div className="overflow-hidden rounded-[20px] bg-surface shadow-[0_2px_16px_rgba(58,37,48,0.06)]">
        <AnimatePresence initial={false}>
          {items.map((term, index) => (
            <motion.div
              key={term}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, height: 0 }}
              transition={{
                duration: ROW_DURATION,
                delay: index * ROW_STAGGER,
                ease: [0.16, 1, 0.3, 1],
              }}
              className="overflow-hidden"
            >
              <button
                type="button"
                onClick={() => onSelect(term)}
                className={`flex w-full items-center gap-3.5 px-5 py-3.5 text-left transition-colors active:bg-blush-soft ${
                  index < items.length - 1 ? "border-b border-blush-border" : ""
                }`}
              >
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-blush-soft">
                  <Clock className="h-4 w-4 text-ink-faint" strokeWidth={1.75} />
                </span>

                <span className="flex-1 truncate text-[15px] text-ink">
                  {term}
                </span>

                <span
                  role="button"
                  tabIndex={0}
                  onClick={(e) => {
                    e.stopPropagation();
                    setItems((prev) => prev.filter((t) => t !== term));
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.stopPropagation();
                      setItems((prev) => prev.filter((t) => t !== term));
                    }
                  }}
                  aria-label={`Remove ${term} from recent searches`}
                  className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-ink-faint transition-colors hover:bg-blush-soft hover:text-ink-muted"
                >
                  <X className="h-3.5 w-3.5" strokeWidth={2} />
                </span>
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
