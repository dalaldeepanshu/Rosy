export type MessageStatus = "sent" | "delivered" | "read";

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  text: string;
  timestamp: string; // ISO string
  status?: MessageStatus;
}

export interface Chat {
  id: string;
  name: string;
  avatarUrl?: string;
  avatarColor?: string; // fallback gradient/color when no image
  lastMessage: string;
  lastMessageTimestamp: string; // ISO string
  unreadCount: number;
  isOnline?: boolean;
  isMuted?: boolean;
  isPinned?: boolean;
  isTyping?: boolean;
}
