export type MessageSender = "me" | "them";
export type MessageKind = "text" | "image";
export type DeliveryStatus = "sent" | "delivered" | "read";

export interface ReplyReference {
  messageId: string;
  senderLabel: string;
  preview: string;
}

export interface ConversationMessage {
  id: string;
  kind: MessageKind;
  sender: MessageSender;
  text?: string;
  imageUrl?: string;
  timestamp: string; // ISO string
  status?: DeliveryStatus; // only rendered for sender: "me"
  replyTo?: ReplyReference;
}

export interface ConversationProfile {
  chatId: string;
  name: string;
  avatarColor: string;
  isOnline: boolean;
  lastSeenLabel: string;
}
