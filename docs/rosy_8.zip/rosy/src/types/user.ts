export interface User {
  id: string;
  name: string;
  handle: string;
  avatarUrl?: string;
  avatarColor?: string;
  bio?: string;
  isOnline?: boolean;
}
