export const siteConfig = {
  name: "Rosy",
  description: "A warm, calm place to keep up with the people you talk to most.",
  url: "https://rosy.app",
};
