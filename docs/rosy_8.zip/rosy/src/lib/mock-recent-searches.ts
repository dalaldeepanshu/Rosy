// Temporary sample data — no persistence, no backend wired up yet.
// Capped at 5 entries per the Recent Searches spec.
export const mockRecentSearches: string[] = [
  "Maya Torres",
  "Book Club",
  "trip",
  "Studio Standup",
  "Elena",
];
