export interface FontOption {
  id: string;
  name: string;
  /** Generic CSS fallback stack used to visually differentiate previews. */
  cssFontFamily: string;
  italic?: boolean;
  weight?: 400 | 500 | 600 | 700;
}

// Mock catalogue only — no real font files are bundled. Each entry maps
// to a generic system font stack so the list feels visually distinct
// while remaining lightweight. Real webfonts can be swapped in later
// without changing the shape of this data or any consuming component.
const ADJECTIVES = [
  "Soft", "Elegant", "Cute", "Modern", "Dream", "Moon", "Rose", "Classic",
  "Velvet", "Golden", "Whisper", "Ivory", "Warm", "Quiet", "Gentle",
  "Studio", "Blossom", "Evening", "Silky", "Pure", "Vintage", "Bold",
  "Chic", "Serene", "Lush",
];

const NOUNS = [
  "Bloom", "Serif", "Script", "Sans", "Notes", "Light", "Letter", "Mono",
  "Type", "Round", "Grotesk", "Note", "Curve", "Text", "Display", "Ink",
  "Petal", "Story", "Verse", "Muse",
];

const GENERIC_STACKS: { family: string; italic?: boolean; weight?: 400 | 500 | 600 | 700 }[] = [
  { family: "Georgia, 'Times New Roman', serif", weight: 400 },
  { family: "'Segoe UI', system-ui, sans-serif", weight: 500 },
  { family: "'Brush Script MT', cursive", italic: true, weight: 400 },
  { family: "'Courier New', monospace", weight: 500 },
  { family: "Verdana, Geneva, sans-serif", weight: 600 },
  { family: "Cambria, 'Palatino Linotype', serif", italic: true, weight: 400 },
];

function stackForNoun(noun: string) {
  if (["Script", "Note", "Curve", "Story", "Verse"].includes(noun)) {
    return GENERIC_STACKS[2];
  }
  if (["Serif", "Letter", "Ink", "Display"].includes(noun)) {
    return GENERIC_STACKS[0];
  }
  if (["Mono", "Grotesk"].includes(noun)) {
    return GENERIC_STACKS[3];
  }
  if (["Bloom", "Petal", "Round", "Muse"].includes(noun)) {
    return GENERIC_STACKS[5];
  }
  return GENERIC_STACKS[1];
}

function generateFonts(count: number): FontOption[] {
  const fonts: FontOption[] = [];
  for (let i = 0; i < count; i++) {
    const adjective = ADJECTIVES[i % ADJECTIVES.length];
    const noun = NOUNS[i % NOUNS.length];
    const name = `${adjective} ${noun}`;
    const stack = stackForNoun(noun);

    fonts.push({
      id: `font-${i + 1}`,
      name,
      cssFontFamily: stack.family,
      italic: stack.italic,
      weight: stack.weight ?? 400,
    });
  }
  return fonts;
}

// Exactly 100 entries — adjectives (25) × nouns (20) share a period of
// lcm(25, 20) = 100, so every name in this list is unique.
export const mockFonts: FontOption[] = generateFonts(100);
