import type { ConversationMessage, ConversationProfile } from "@/types/conversation";

interface MockConversation {
  profile: ConversationProfile;
  messages: ConversationMessage[];
}

const defaultProfile = (chatId: string): ConversationProfile => ({
  chatId,
  name: "Rosy Friend",
  avatarColor: "from-rose-300 to-rose-500",
  isOnline: false,
  lastSeenLabel: "last seen recently",
});

const conversations: Record<string, MockConversation> = {
  "1": {
    profile: {
      chatId: "1",
      name: "Maya Torres",
      avatarColor: "from-rose-300 to-rose-500",
      isOnline: true,
      lastSeenLabel: "Online",
    },
    messages: [
      {
        id: "m1",
        kind: "text",
        sender: "them",
        text: "Hey! Did you get a chance to look at the moodboard?",
        timestamp: "2026-07-09T09:02:00Z",
      },
      {
        id: "m2",
        kind: "text",
        sender: "me",
        text: "Just opened it now, the palette is gorgeous 😍",
        timestamp: "2026-07-09T09:05:00Z",
        status: "read",
      },
      {
        id: "m3",
        kind: "image",
        sender: "them",
        imageUrl: "https://picsum.photos/seed/rosy-maya-1/480/360",
        timestamp: "2026-07-09T09:06:00Z",
      },
      {
        id: "m4",
        kind: "text",
        sender: "them",
        text: "This is the cover direction I was thinking of",
        timestamp: "2026-07-09T09:06:30Z",
      },
      {
        id: "m5",
        kind: "text",
        sender: "me",
        text: "Love this — can we push the accent a little warmer though?",
        timestamp: "2026-07-10T08:40:00Z",
        status: "delivered",
      },
      {
        id: "m6",
        kind: "text",
        sender: "them",
        text: "Totally agree, I'll adjust it",
        timestamp: "2026-07-10T08:42:00Z",
        replyTo: {
          messageId: "m5",
          senderLabel: "You",
          preview: "Love this — can we push the accent a little warmer though?",
        },
      },
      {
        id: "m7",
        kind: "text",
        sender: "them",
        text:
          "Also, quick thought — what if we let the whole deck breathe a bit more between sections? Right now it feels a touch dense when you flip through it quickly, and I think a little more whitespace could make the transitions land better without changing any of the actual content.",
        timestamp: "2026-07-10T09:14:00Z",
      },
      {
        id: "m8",
        kind: "text",
        sender: "me",
        text: "Sent the deck over, let me know what you think ✨",
        timestamp: "2026-07-10T09:14:00Z",
        status: "sent",
      },
    ],
  },
  "3": {
    profile: {
      chatId: "3",
      name: "Jonah Kim",
      avatarColor: "from-gold to-rose-300",
      isOnline: true,
      lastSeenLabel: "Online",
    },
    messages: [
      {
        id: "m1",
        kind: "text",
        sender: "them",
        text: "Morning! Ready for standup?",
        timestamp: "2026-07-10T07:30:00Z",
      },
      {
        id: "m2",
        kind: "text",
        sender: "me",
        text: "Yep, joining in 2 minutes",
        timestamp: "2026-07-10T07:31:00Z",
        status: "read",
      },
    ],
  },
  "6": {
    profile: {
      chatId: "6",
      name: "Marcus Chen",
      avatarColor: "from-sage to-rose-300",
      isOnline: false,
      lastSeenLabel: "last seen yesterday at 9:05 PM",
    },
    messages: [],
  },
};

export function getMockConversation(chatId: string): MockConversation {
  return (
    conversations[chatId] ?? {
      profile: defaultProfile(chatId),
      messages: [],
    }
  );
}
