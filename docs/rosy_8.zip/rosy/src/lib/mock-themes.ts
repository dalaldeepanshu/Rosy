export interface ThemeOption {
  id: string;
  name: string;
  /** 3-stop gradient used purely for the preview card — no app-wide effect. */
  gradient: [string, string, string];
}

// Presentational only — selecting a theme here does not restyle the app.
export const mockThemes: ThemeOption[] = [
  { id: "rose-light", name: "Rose Light", gradient: ["#FBF6F4", "#F6D6E0", "#C9587A"] },
  { id: "rose-dark", name: "Rose Dark", gradient: ["#2B1B22", "#5A2E42", "#C9587A"] },
  { id: "lavender", name: "Lavender", gradient: ["#F3EEFB", "#D9CBF0", "#8B6FC9"] },
  { id: "ocean", name: "Ocean", gradient: ["#EAF5F7", "#BFE0E8", "#3A7CA5"] },
  { id: "forest", name: "Forest", gradient: ["#EEF5EE", "#BFDCC4", "#4C7A5A"] },
  { id: "sunset", name: "Sunset", gradient: ["#FFF1E6", "#FBC59A", "#E4783C"] },
  { id: "cream", name: "Cream", gradient: ["#FFFCF6", "#F3E9D2", "#C9A96A"] },
  { id: "midnight", name: "Midnight", gradient: ["#1B1E2B", "#2E3452", "#5A6BAE"] },
  { id: "blush", name: "Blush", gradient: ["#FDF3F5", "#F6D6E0", "#E58FA8"] },
  { id: "classic", name: "Classic", gradient: ["#FAFAFA", "#E4E4E4", "#3A2530"] },
];
