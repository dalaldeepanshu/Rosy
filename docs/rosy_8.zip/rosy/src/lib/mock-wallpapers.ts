export type WallpaperPattern = "solid" | "dots" | "waves" | "grid" | "petals";

export interface WallpaperOption {
  id: string;
  name: string;
  gradient: [string, string];
  pattern: WallpaperPattern;
}

// Presentational only — selecting a wallpaper here does not change any
// actual conversation background.
export const mockWallpapers: WallpaperOption[] = [
  { id: "petal-dawn", name: "Petal Dawn", gradient: ["#FBF6F4", "#F6D6E0"], pattern: "petals" },
  { id: "rose-mist", name: "Rose Mist", gradient: ["#FCEEF2", "#E58FA8"], pattern: "dots" },
  { id: "sage-linen", name: "Sage Linen", gradient: ["#F3F8F4", "#DCEAE1"], pattern: "grid" },
  { id: "golden-hour", name: "Golden Hour", gradient: ["#FFF8EA", "#F5E4C8"], pattern: "waves" },
  { id: "porcelain", name: "Porcelain", gradient: ["#FFFFFF", "#F5EBE8"], pattern: "solid" },
  { id: "twilight", name: "Twilight", gradient: ["#2B1B22", "#5A2E42"], pattern: "dots" },
  { id: "lavender-fog", name: "Lavender Fog", gradient: ["#F3EEFB", "#D9CBF0"], pattern: "waves" },
  { id: "ocean-breeze", name: "Ocean Breeze", gradient: ["#EAF5F7", "#BFE0E8"], pattern: "grid" },
  { id: "warm-clay", name: "Warm Clay", gradient: ["#FBF0EA", "#E8C7AE"], pattern: "petals" },
  { id: "ink-wash", name: "Ink Wash", gradient: ["#F4F4F4", "#D6D6D6"], pattern: "solid" },
];
