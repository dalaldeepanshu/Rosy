import type { LucideIcon } from "lucide-react";
import { MessageCircle, Flower2, User } from "lucide-react";

export interface NavItem {
  label: string;
  href: string;
  icon: LucideIcon;
}

export const NAV_ITEMS: NavItem[] = [
  { label: "Chats", href: "/chats", icon: MessageCircle },
  { label: "Rosy AI", href: "/rosy-ai", icon: Flower2 },
  { label: "Me", href: "/me", icon: User },
];

export const ANIMATION = {
  pageDuration: 0.28,
  staggerDelay: 0.045,
  listItemDuration: 0.32,
};

export const APP_NAME = "Rosy";
