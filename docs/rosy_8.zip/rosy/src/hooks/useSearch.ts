"use client";

import { useMemo, useState } from "react";
import type { Chat } from "@/types/chat";

/**
 * Filters a list of chats by name or last message against a
 * locally-managed query string.
 */
export function useSearch(chats: Chat[]) {
  const [query, setQuery] = useState("");

  const results = useMemo(() => {
    if (!query.trim()) return chats;
    const q = query.trim().toLowerCase();
    return chats.filter(
      (chat) =>
        chat.name.toLowerCase().includes(q) ||
        chat.lastMessage.toLowerCase().includes(q)
    );
  }, [chats, query]);

  return { query, setQuery, results };
}
