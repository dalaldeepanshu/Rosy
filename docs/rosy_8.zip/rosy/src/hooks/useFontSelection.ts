"use client";

import { useState } from "react";
import { mockFonts, type FontOption } from "@/lib/mock-fonts";

/**
 * Manages the currently *previewed* font for the Personalization screen.
 *
 * This is intentionally local-only for now — selecting a font here does
 * not restyle the rest of the app. The hook exists as a seam: once a
 * backend/settings layer lands, this same shape (fonts, selectedFont,
 * selectFont) can be moved behind a global context/provider so a single
 * selected font can be applied app-wide without reworking the UI that
 * consumes it.
 */
export function useFontSelection(initialFontId: string = mockFonts[0].id) {
  const [selectedFontId, setSelectedFontId] = useState(initialFontId);

  const selectedFont: FontOption =
    mockFonts.find((font) => font.id === selectedFontId) ?? mockFonts[0];

  return {
    fonts: mockFonts,
    selectedFontId,
    selectedFont,
    selectFont: setSelectedFontId,
  };
}
