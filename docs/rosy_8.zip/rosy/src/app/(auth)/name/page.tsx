"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { AuthInput } from "@/components/auth/AuthInput";
import { AuthButton } from "@/components/auth/AuthButton";
import { AuthTransition } from "@/components/auth/AuthTransition";

const MAX_LENGTH = 25;

export default function DisplayNamePage() {
  const router = useRouter();
  const [name, setName] = useState("");

  const canContinue = name.trim().length > 0;

  return (
    <AuthTransition>
      <div className="flex flex-1 flex-col px-6 py-10">
        <div className="flex flex-col gap-2">
          <h1 className="font-quicksand text-[24px] font-semibold tracking-tight text-auth-text">
            What should people call you?
          </h1>
          <p className="font-nunito text-[15px] leading-relaxed text-auth-muted">
            Choose the name people will see.
          </p>
        </div>

        <div className="mt-8 flex flex-col gap-2">
          <AuthInput
            value={name}
            onChange={(e) => setName(e.target.value.slice(0, MAX_LENGTH))}
            placeholder="Your name"
            maxLength={MAX_LENGTH}
            autoFocus
          />
          <span className="self-end font-nunito text-[12px] text-auth-muted">
            {name.length}/{MAX_LENGTH}
          </span>
        </div>

        <div className="mt-auto pt-10">
          <AuthButton
            disabled={!canContinue}
            onClick={() => router.push("/loading")}
          >
            Continue
          </AuthButton>
        </div>
      </div>
    </AuthTransition>
  );
}
