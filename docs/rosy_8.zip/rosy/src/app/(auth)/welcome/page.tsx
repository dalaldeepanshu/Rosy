"use client";

import { useRouter } from "next/navigation";
import { RosyLogo } from "@/components/auth/RosyLogo";
import { AuthButton } from "@/components/auth/AuthButton";
import { AuthTransition } from "@/components/auth/AuthTransition";

export default function WelcomePage() {
  const router = useRouter();

  return (
    <AuthTransition>
      <div className="flex flex-1 flex-col justify-between px-6 py-12">
        <div className="flex flex-1 flex-col items-center justify-center gap-6 text-center">
          <RosyLogo size="md" />
          <div className="flex flex-col gap-2">
            <h1 className="font-quicksand text-[26px] font-semibold tracking-tight text-auth-text">
              Welcome to Rosy
            </h1>
            <p className="font-nunito text-[15px] leading-relaxed text-auth-muted">
              Real conversations.
              <br />
              No noise.
            </p>
          </div>
        </div>

        <div className="flex flex-col gap-4">
          <AuthButton onClick={() => router.push("/phone")}>
            Continue with Phone
          </AuthButton>
          <p className="px-4 text-center font-nunito text-[12px] leading-relaxed text-auth-muted">
            By continuing you agree to the Terms and Privacy Policy.
          </p>
        </div>
      </div>
    </AuthTransition>
  );
}
