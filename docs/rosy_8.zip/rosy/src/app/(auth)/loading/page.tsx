"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { RosyLogo } from "@/components/auth/RosyLogo";

export default function LoadingAccountPage() {
  const router = useRouter();

  useEffect(() => {
    const id = setTimeout(() => {
      router.push("/chats");
    }, 1800);
    return () => clearTimeout(id);
  }, [router]);

  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-6 px-8">
      <RosyLogo size="md" />
      <p className="font-nunito text-[15px] text-auth-muted">
        Setting up your account...
      </p>
      <div className="flex items-center gap-2">
        {[0, 1, 2].map((i) => (
          <motion.span
            key={i}
            className="h-2 w-2 rounded-full bg-auth-accent"
            animate={{ opacity: [0.3, 1, 0.3] }}
            transition={{
              duration: 1,
              repeat: Infinity,
              delay: i * 0.15,
              ease: "easeInOut",
            }}
          />
        ))}
      </div>
    </div>
  );
}
