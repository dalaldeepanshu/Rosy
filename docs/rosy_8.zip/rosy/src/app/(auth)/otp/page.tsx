"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { OtpInput } from "@/components/auth/OtpInput";
import { ResendTimer } from "@/components/auth/ResendTimer";
import { AuthButton } from "@/components/auth/AuthButton";
import { AuthTransition } from "@/components/auth/AuthTransition";

export default function OtpPage() {
  const router = useRouter();
  const [code, setCode] = useState<string[]>(["", "", "", "", "", ""]);

  const canVerify = code.every((digit) => digit !== "");

  return (
    <AuthTransition>
      <div className="flex flex-1 flex-col px-6 py-6">
        <button
          type="button"
          onClick={() => router.back()}
          aria-label="Go back"
          className="flex h-11 w-11 items-center justify-center rounded-full text-auth-text transition-colors hover:bg-auth-border/40"
        >
          <ArrowLeft className="h-5 w-5" strokeWidth={2} />
        </button>

        <div className="mt-6 flex flex-col gap-2">
          <h1 className="font-quicksand text-[24px] font-semibold tracking-tight text-auth-text">
            Verify your number
          </h1>
          <p className="font-nunito text-[15px] leading-relaxed text-auth-muted">
            Enter the 6-digit code sent to your phone.
          </p>
        </div>

        <div className="mt-8">
          <OtpInput value={code} onChange={setCode} />
        </div>

        <div className="mt-5">
          <ResendTimer />
        </div>

        <div className="mt-auto pt-10">
          <AuthButton
            disabled={!canVerify}
            onClick={() => router.push("/name")}
          >
            Verify
          </AuthButton>
        </div>
      </div>
    </AuthTransition>
  );
}
