"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { RosyLogo } from "@/components/auth/RosyLogo";

export default function SplashPage() {
  const router = useRouter();

  useEffect(() => {
    const id = setTimeout(() => {
      router.push("/welcome");
    }, 1500);
    return () => clearTimeout(id);
  }, [router]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
      className="flex min-h-screen flex-col items-center justify-center gap-4 px-8"
    >
      <RosyLogo size="lg" />
      <h1 className="font-quicksand text-3xl font-semibold tracking-tight text-auth-text">
        Rosy
      </h1>
      <p className="text-center font-nunito text-[15px] leading-relaxed text-auth-muted">
        Private.
        <br />
        Beautiful.
        <br />
        Simple.
      </p>
    </motion.div>
  );
}
