"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { PhoneNumberInput } from "@/components/auth/PhoneNumberInput";
import { AuthButton } from "@/components/auth/AuthButton";
import { AuthTransition } from "@/components/auth/AuthTransition";

export default function PhoneNumberPage() {
  const router = useRouter();
  const [phone, setPhone] = useState("");

  const canContinue = phone.replace(/\s/g, "").length >= 10;

  return (
    <AuthTransition>
      <div className="flex flex-1 flex-col px-6 py-6">
        <button
          type="button"
          onClick={() => router.back()}
          aria-label="Go back"
          className="flex h-11 w-11 items-center justify-center rounded-full text-auth-text transition-colors hover:bg-auth-border/40"
        >
          <ArrowLeft className="h-5 w-5" strokeWidth={2} />
        </button>

        <div className="mt-6 flex flex-col gap-2">
          <h1 className="font-quicksand text-[24px] font-semibold tracking-tight text-auth-text">
            Enter your phone number
          </h1>
        </div>

        <div className="mt-8 flex flex-col gap-3">
          <PhoneNumberInput value={phone} onChange={setPhone} />
          <p className="px-1 font-nunito text-[13px] leading-relaxed text-auth-muted">
            We&apos;ll send you a verification code.
          </p>
        </div>

        <div className="mt-auto pt-10">
          <AuthButton
            disabled={!canContinue}
            onClick={() => router.push("/otp")}
          >
            Continue
          </AuthButton>
        </div>
      </div>
    </AuthTransition>
  );
}
