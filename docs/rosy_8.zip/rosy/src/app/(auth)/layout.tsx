import { Quicksand, Nunito } from "next/font/google";

const quicksand = Quicksand({
  subsets: ["latin"],
  variable: "--font-quicksand",
  weight: ["500", "600", "700"],
});

const nunito = Nunito({
  subsets: ["latin"],
  variable: "--font-nunito",
  weight: ["400", "500", "600"],
});

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div
      className={`${quicksand.variable} ${nunito.variable} min-h-screen bg-auth-bg font-nunito text-auth-text`}
    >
      <div className="mx-auto min-h-screen w-full max-w-md">{children}</div>
    </div>
  );
}
