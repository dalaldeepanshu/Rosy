"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { TopBar } from "@/components/layout/TopBar";
import { ChatList } from "@/components/chat/ChatList";
import { ChatListSkeleton } from "@/components/chat/ChatListSkeleton";
import { PageTransition } from "@/components/shared/PageTransition";
import { useSearch } from "@/hooks/useSearch";
import { mockChats } from "@/lib/mock-data";

const MOCK_LOAD_DELAY_MS = 650;

export default function ChatsPage() {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(true);
  const { query, setQuery, results } = useSearch(mockChats);

  useEffect(() => {
    const id = setTimeout(() => setIsLoading(false), MOCK_LOAD_DELAY_MS);
    return () => clearTimeout(id);
  }, []);

  return (
    <PageTransition>
      <TopBar
        title="Rosy"
        showLogo
        showSearch
        searchValue={query}
        onSearchChange={setQuery}
        onSearchClick={() => router.push("/search")}
      />

      <AnimatePresence mode="wait" initial={false}>
        {isLoading ? (
          <motion.div
            key="skeleton"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
          >
            <ChatListSkeleton />
          </motion.div>
        ) : (
          <motion.div
            key="list"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
          >
            <ChatList chats={results} totalChatCount={mockChats.length} />
          </motion.div>
        )}
      </AnimatePresence>
    </PageTransition>
  );
}
