"use client";

import { motion } from "framer-motion";
import { RosyLogo } from "@/components/auth/RosyLogo";

/**
 * Rosy AI — a quiet, premium placeholder. No chat, no input, no
 * illustration. Just the mark, a short line, and a "Coming Soon"
 * label, generously spaced and centered.
 */
export default function RosyAiPage() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="flex h-full min-h-[70vh] flex-col items-center justify-center px-8 text-center"
    >
      <RosyLogo size="lg" />

      <h1 className="mt-8 font-display text-2xl font-semibold tracking-tight text-ink">
        Rosy AI
      </h1>

      <p className="mt-3 max-w-[260px] text-[15px] leading-relaxed text-ink-muted">
        Your intelligent companion is on the way.
      </p>

      <span className="mt-8 rounded-full bg-rose-50 px-4 py-1.5 text-xs font-medium uppercase tracking-wide text-rose-500">
        Coming Soon
      </span>
    </motion.div>
  );
}
