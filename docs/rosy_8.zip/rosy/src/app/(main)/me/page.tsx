"use client";

import { TopBar } from "@/components/layout/TopBar";
import { PageTransition } from "@/components/shared/PageTransition";
import { ProfileHeader } from "@/components/profile/ProfileHeader";
import { ProfileCard } from "@/components/profile/ProfileCard";
import { ProfileMenu } from "@/components/profile/ProfileMenu";

const mockProfile = {
  name: "Dishu",
  phone: "+91 ******1234",
  bio: "Living one message at a time 🌹",
  avatarUrl: "https://picsum.photos/seed/rosy-me/240/240",
};

export default function MePage() {
  return (
    <PageTransition>
      <TopBar title="Me" showEdit />

      <ProfileHeader
        name={mockProfile.name}
        phone={mockProfile.phone}
        bio={mockProfile.bio}
        avatarUrl={mockProfile.avatarUrl}
      />

      <ProfileCard
        name={mockProfile.name}
        phone={mockProfile.phone}
        bio={mockProfile.bio}
      />

      <ProfileMenu />

      <div className="h-8" />
    </PageTransition>
  );
}
