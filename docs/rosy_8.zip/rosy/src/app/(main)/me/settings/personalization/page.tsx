"use client";

import { PageTransition } from "@/components/shared/PageTransition";
import { PersonalizationHeader } from "@/components/personalization/PersonalizationHeader";
import { ThemeSection } from "@/components/personalization/ThemeSection";
import { WallpaperSection } from "@/components/personalization/WallpaperSection";
import { FontSection } from "@/components/personalization/FontSection";

export default function PersonalizationPage() {
  return (
    <PageTransition>
      <PersonalizationHeader />
      <ThemeSection />
      <WallpaperSection />
      <FontSection />
      <div className="h-10" />
    </PageTransition>
  );
}
