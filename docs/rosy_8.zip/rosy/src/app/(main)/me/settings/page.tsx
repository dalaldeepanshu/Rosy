"use client";

import { PageTransition } from "@/components/shared/PageTransition";
import { SettingsHeader } from "@/components/settings/SettingsHeader";
import { SettingsMenu } from "@/components/settings/SettingsMenu";

export default function SettingsPage() {
  return (
    <PageTransition>
      <SettingsHeader />
      <SettingsMenu />
      <div className="h-8" />
    </PageTransition>
  );
}
