import { BottomNav } from "@/components/layout/BottomNav";

export default function MainLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="mx-auto flex min-h-screen max-w-md flex-col bg-blush">
      <div className="flex-1">{children}</div>
      <BottomNav />
    </div>
  );
}
