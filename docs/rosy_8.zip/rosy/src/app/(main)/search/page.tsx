"use client";

import { AnimatePresence, motion } from "framer-motion";
import { PageTransition } from "@/components/shared/PageTransition";
import { SearchHeader } from "@/components/search/SearchHeader";
import { SearchField } from "@/components/search/SearchField";
import { RecentSearches } from "@/components/search/RecentSearches";
import { SearchResultsList } from "@/components/search/SearchResultsList";
import { useSearch } from "@/hooks/useSearch";
import { mockChats } from "@/lib/mock-data";

export default function SearchPage() {
  const { query, setQuery, results } = useSearch(mockChats);
  const isSearching = query.trim().length > 0;

  return (
    <PageTransition>
      <SearchHeader />
      <SearchField value={query} onChange={setQuery} />

      <AnimatePresence mode="wait" initial={false}>
        {isSearching ? (
          <motion.div
            key="results"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
          >
            <SearchResultsList results={results} />
          </motion.div>
        ) : (
          <motion.div
            key="recent"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
          >
            <RecentSearches onSelect={setQuery} />
          </motion.div>
        )}
      </AnimatePresence>

      <div className="h-8" />
    </PageTransition>
  );
}
