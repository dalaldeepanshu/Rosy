"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { ConversationHeader } from "@/components/chat/ConversationHeader";
import { DateSeparator, getDayKey } from "@/components/chat/DateSeparator";
import { MessageBubble } from "@/components/chat/MessageBubble";
import { MessageInput } from "@/components/chat/MessageInput";
import { DeleteMessageSheet } from "@/components/chat/DeleteMessageSheet";
import { EmptyConversation } from "@/components/chat/EmptyConversation";
import { getMockConversation } from "@/lib/mock-messages";
import type {
  ConversationMessage,
  ReplyReference,
} from "@/types/conversation";

export default function ChatScreenPage({
  params,
}: {
  params: { chatId: string };
}) {
  const { chatId } = params;
  const conversation = useMemo(() => getMockConversation(chatId), [chatId]);

  const [messages, setMessages] = useState<ConversationMessage[]>(
    conversation.messages
  );
  const [draft, setDraft] = useState("");
  const [replyTo, setReplyTo] = useState<ReplyReference | null>(null);
  const [sheetMessage, setSheetMessage] = useState<ConversationMessage | null>(
    null
  );
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
  }, [messages.length]);

  function handleSend() {
    const text = draft.trim();
    if (!text) return;

    const newMessage: ConversationMessage = {
      id: `local-${Date.now()}`,
      kind: "text",
      sender: "me",
      text,
      timestamp: new Date().toISOString(),
      status: "sent",
      replyTo: replyTo ?? undefined,
    };

    setMessages((prev) => [...prev, newMessage]);
    setDraft("");
    setReplyTo(null);
  }

  function handleTapReply(message: ConversationMessage) {
    setReplyTo({
      messageId: message.id,
      senderLabel: message.sender === "me" ? "You" : conversation.profile.name,
      preview:
        message.kind === "image"
          ? "Photo"
          : (message.text ?? "").slice(0, 120),
    });
  }

  let lastDayKey = "";

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col bg-blush">
      <ConversationHeader profile={conversation.profile} />

      <div ref={scrollRef} className="flex flex-1 flex-col overflow-y-auto py-3">
        {messages.length === 0 ? (
          <EmptyConversation />
        ) : (
          messages.map((message) => {
            const dayKey = getDayKey(message.timestamp);
            const showSeparator = dayKey !== lastDayKey;
            lastDayKey = dayKey;

            return (
              <div key={message.id} className="flex flex-col">
                {showSeparator && (
                  <DateSeparator timestamp={message.timestamp} />
                )}
                <div className="py-1">
                  <MessageBubble
                    message={message}
                    onLongPress={setSheetMessage}
                    onTapReply={handleTapReply}
                  />
                </div>
              </div>
            );
          })
        )}
      </div>

      <MessageInput
        value={draft}
        onChange={setDraft}
        onSend={handleSend}
        replyTo={replyTo}
        onCancelReply={() => setReplyTo(null)}
      />

      <DeleteMessageSheet
        open={sheetMessage !== null}
        onClose={() => setSheetMessage(null)}
      />
    </div>
  );
}
