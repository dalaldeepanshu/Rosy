// Design tokens for Rosy — mirrors tailwind.config.ts for use in
// JS/TS contexts (e.g. framer-motion, canvas, inline styles) where
// Tailwind classes aren't applicable.

export const colors = {
  blush: "#FBF6F4",
  blushSoft: "#F5EBE8",
  blushBorder: "#EBDDD9",
  surface: "#FFFFFF",
  ink: "#3A2530",
  inkMuted: "#8C7480",
  inkFaint: "#B7A6AD",
  rose50: "#FCEEF2",
  rose100: "#F6D6E0",
  rose300: "#E58FA8",
  rose500: "#C9587A",
  rose600: "#AD4368",
  rose700: "#8A3454",
  sage: "#6E9C82",
  sageLight: "#DCEAE1",
  gold: "#D9A054",
  goldLight: "#F5E4C8",
} as const;

export const typography = {
  display: "var(--font-fraunces)",
  sans: "var(--font-inter)",
  mono: "var(--font-plex-mono)",
  scale: {
    xs: "0.75rem",
    sm: "0.875rem",
    base: "1rem",
    lg: "1.125rem",
    xl: "1.375rem",
    "2xl": "1.75rem",
  },
} as const;

export const motion = {
  easeOut: [0.16, 1, 0.3, 1],
  pageDuration: 0.28,
  staggerDelay: 0.045,
} as const;
